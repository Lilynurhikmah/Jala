# JALA – Operations Management System

Internal operations dashboard for e-waste projects: Household, Collaboration & ITAD, Material Database (Sales) and SOP Library.

**Status: Phase 1. This is a static website that shows example (dummy) data.**
There is no database, no login and no saving yet. Buttons like "+ Create Project" explain that the feature comes in a later phase. They do not pretend to save anything.

---

## 1. Project structure

```text
jala-operations/
├── index.html                     ← Overview Project (main entry point)
├── pages/
│   ├── household.html             ← Household Project
│   ├── collaboration-itad.html    ← Collaboration & ITAD – BCA UPS
│   ├── material-database.html     ← Material Database (Sales)
│   └── sop-library.html           ← SOP Library
├── 404.html                       ← "Page not found" page (used by Netlify)
├── assets/
│   ├── css/app.css                ← layout, sidebar, mobile menu, fonts, states
│   ├── js/
│   │   ├── config.js              ← settings (data source; future Supabase URL)
│   │   ├── data/dummy-data.js     ← ALL example data shown on the pages
│   │   ├── data-service.js        ← the only place pages get data from
│   │   ├── template.js            ← fills page templates with data
│   │   └── app.js                 ← sidebar, navigation, mobile menu, dialogs
│   ├── fonts/                     ← Inter + Space Grotesk (self-hosted, OFL license)
│   └── images/favicon.svg
├── docs/
│   ├── ROADMAP.md                 ← plan for database, login, roles
│   └── supabase-schema.draft.sql  ← DRAFT database design (not applied)
├── netlify.toml                   ← Netlify settings (no build step)
├── robots.txt                     ← asks search engines not to index the site
├── .gitignore
└── README.md
```

There are no external dependencies: no CDN, no framework, no build tools. Everything loads from this folder.

### How a page works
Each page's HTML holds its layout, with repeating parts written as
`<template data-for="rows" data-as="r"> … {{r.material}} … </template>`.
When the page opens, `app.js` asks `JALA.dataService.getPageData('<page>')` for the data and fills the templates. While it loads you see "Memuat data…". If loading fails you see an error box with a "Coba lagi" (retry) button.

### Editing content
* **Change numbers or text in lists or tables:** edit `assets/js/data/dummy-data.js`.
* **Change fixed text, headings or layout:** edit the page's `.html` file.
* **Add a menu item:** add one entry to `ROUTES` in `assets/js/app.js`.

> ⚠️ Everything in this folder is visible to anyone who opens the website. Do **not** put confidential company or client data in these files.

---

## 2. Run it on your computer

**Option A (simplest):** double-click `index.html`. It opens in your browser and all pages work.

**Option B (closest to the live site):** run a small local web server from inside the folder:

```bash
# Python 3 (Windows: use "py" instead of "python3")
python3 -m http.server 8000
# then open http://localhost:8000
```

---

## 3. Put it on GitHub

### Option A: in the browser (no software needed)
1. Sign in at <https://github.com>.
2. Top-right **+** → **New repository**.
3. **Repository name:** `jala-operations`.
4. Choose **Private** (recommended for an internal company tool; Netlify Free works with private repos). Choose **Public** only if everything in it may be seen by anyone.
5. Do **not** tick "Add a README" (this project already has one). Click **Create repository**.
6. On the next page click the link **"uploading an existing file"**.
7. Open the `jala-operations` folder on your computer, select **everything inside it** (all files and the `assets`, `pages` and `docs` folders, plus `.gitignore` and `netlify.toml`), and drag it into the browser window.
   *On Mac, press `Cmd + Shift + .` in Finder to show hidden files like `.gitignore`. On Windows, enable "Hidden items" in File Explorer's View menu.*
8. Wait until all files are listed, then click **Commit changes**.
9. Check that `index.html` is at the **top level** of the repository, not inside an extra folder.

### Option B: with Git (command line)
```bash
cd jala-operations
git init
git add .
git commit -m "JALA phase 1: static website"
git branch -M main
git remote add origin https://github.com/<your-username>/jala-operations.git
git push -u origin main
```

---

## 4. Publish on Netlify (free)

1. Go to <https://app.netlify.com> and click **Sign up** → **Sign up with GitHub** (or log in).
2. Click **Add new project** (also shown as **Add new site**) → **Import an existing project**.
3. Click **GitHub** and allow Netlify to access GitHub. If asked, choose **Only select repositories** → pick `jala-operations` → **Install / Save**.
4. Select the `jala-operations` repository.
5. Deployment settings. These are already in `netlify.toml`, so just check them:
   * **Branch to deploy:** `main`
   * **Base directory:** *(leave empty)*
   * **Build command:** *(leave empty, because there is no build step)*
   * **Publish directory:** `.` *(or leave empty)*
6. Optional: set the **Project name** to `jala-operations`. Your address will then be `https://jala-operations.netlify.app` if the name is still free. If it is taken, choose another name such as `jala-ops-yourcompany`.
7. Click **Deploy**.
8. Wait for the status to show **Published** (usually under a minute). Click the green link to open your site.
9. Check that all five menu items open, on your computer and on your phone.

**After that, updates are automatic:** every time you change files on GitHub (upload or push), Netlify publishes the new version within about a minute.

You can change the address later under **Project configuration → Change project name**.

### Netlify Free plan limits (check current limits at netlify.com/pricing)
* Free plans include a monthly allowance of bandwidth and build minutes. This small static site (≈0.5 MB) uses very little.
* The site is **public on the internet**: anyone with the link can open it. Password protection for the whole site is a paid Netlify feature. Real access control comes in Phase 2 through employee login.
* `robots.txt` and an `X-Robots-Tag` header ask search engines not to list the site. This is a request, not a lock.

---

## 5. What is done and what is not

| Area | Status |
|---|---|
| All 5 sections, original design, content and data preserved | ✅ Done |
| Sidebar navigation between all pages, active-page highlight | ✅ Done (was broken in the original export) |
| Responsive: desktop, laptop, tablet, phone (slide-in menu) | ✅ Done |
| Loading and error states, retry | ✅ Done |
| Fonts self-hosted, no React/CDN dependency, ~0.5 MB total | ✅ Done |
| Netlify config, 404 page, security headers, no-index | ✅ Done |
| Data layer ready for Supabase (`data-service.js`) | ✅ Prepared |
| "+ Create Project", "+ Input E-Waste Baru" | ⏳ Shows a notice; needs the database (Phase 2) |
| Periode (month) filter in Material Database | ⏳ Re-loads data; real filtering needs the database |
| SOP documents (open / download files) | ⏳ Items jump to the BCA SOP section; files need storage (Phase 2) |
| Photos in material tables | ⏳ Placeholders; needs file upload (Phase 2) |
| Employee login, roles, shared data, activity log, reports | ⏳ Phase 2+ (see `docs/ROADMAP.md`) |

No fake login, and no data is stored anywhere. Every figure shown is example data.
