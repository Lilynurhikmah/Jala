/*
 * JALA – data service.
 *
 * Every page asks this one object for its data. Pages never read the dummy
 * file directly, so switching to Supabase later only means implementing the
 * 'supabase' adapter below — the HTML pages and templates stay the same.
 *
 * All methods are async (return Promises), exactly like a real database call.
 */
(function () {
  const JALA = window.JALA;

  const dummyAdapter = {
    async getPageData(pageKey /*, params */) {
      const data = JALA.dummyData && JALA.dummyData[pageKey];
      if (!data) throw new Error('Tidak ada data untuk halaman "' + pageKey + '".');
      // structuredClone so callers can never mutate the shared dummy object
      return structuredClone(data);
    },
  };

  const supabaseAdapter = {
    async getPageData() {
      // Phase 2: load supabase-js, query tables, map rows to the same shape
      // as dummy-data.js. See docs/ROADMAP.md and docs/supabase-schema.draft.sql.
      throw new Error('Koneksi database (Supabase) belum diaktifkan.');
    },
  };

  const adapters = { dummy: dummyAdapter, supabase: supabaseAdapter };

  JALA.dataService = {
    get source() { return JALA.config.dataSource; },
    get isDemoData() { return JALA.config.dataSource === 'dummy'; },
    getPageData(pageKey, params) {
      const adapter = adapters[JALA.config.dataSource];
      if (!adapter) return Promise.reject(new Error('Sumber data tidak dikenal: ' + JALA.config.dataSource));
      return adapter.getPageData(pageKey, params || {});
    },
  };
})();
