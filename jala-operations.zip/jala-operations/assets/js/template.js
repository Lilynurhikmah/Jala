/*
 * JALA – tiny template renderer (no dependencies).
 *
 *   <template data-for="cats" data-as="cat"> ... {{cat.name}} ... </template>
 *
 * repeats its content once per item in the list found at `cats`, and fills
 * every {{path}} in text and attributes. Templates can be nested; inner
 * templates see the outer loop variable (e.g. data-for="cat.stages").
 * All values are inserted as text (never as HTML), so data cannot inject markup.
 */
(function () {
  const TOKEN = /\{\{\s*([\w.]+)\s*\}\}/g;

  function lookup(scope, path) {
    return path.split('.').reduce((v, k) => (v == null ? undefined : v[k]), scope);
  }

  function fill(str, scope) {
    return str.replace(TOKEN, (m, p) => {
      const v = lookup(scope, p);
      return v == null ? '' : String(v);
    });
  }

  function interpolate(root, scope) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let node = walker.currentNode;
    while (node) {
      if (node.nodeType === Node.TEXT_NODE) {
        if (node.nodeValue.includes('{{')) node.nodeValue = fill(node.nodeValue, scope);
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        for (const attr of Array.from(node.attributes)) {
          if (attr.value.includes('{{')) node.setAttribute(attr.name, fill(attr.value, scope));
        }
      }
      node = walker.nextNode();
    }
  }

  function expandLoops(root, scope) {
    // querySelectorAll does not look inside <template>.content, so this only
    // finds loops at the current level; nested loops are handled recursively.
    for (const tpl of Array.from(root.querySelectorAll('template[data-for]'))) {
      const list = lookup(scope, tpl.dataset.for);
      const as = tpl.dataset.as || 'item';
      const out = document.createDocumentFragment();
      (Array.isArray(list) ? list : []).forEach((item, index) => {
        const frag = tpl.content.cloneNode(true);
        const child = Object.assign({}, scope, { [as]: item, $index: index });
        render(frag, child);
        out.appendChild(frag);
      });
      tpl.replaceWith(out);
    }
  }

  function render(root, scope) {
    expandLoops(root, scope);
    interpolate(root, scope);
  }

  window.JALA = window.JALA || {};
  window.JALA.template = { render };
})();
