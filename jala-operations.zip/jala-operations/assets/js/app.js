/*
 * JALA – application shell: sidebar navigation, mobile drawer, page rendering
 * with loading / error states, and placeholders for not-yet-built features.
 */
(function () {
  const JALA = window.JALA;
  const body = document.body;
  const ROOT = body.dataset.root || '.';
  const PAGE = body.dataset.page;

  const ICON = (paths) =>
    '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + paths + '</svg>';

  // Single source of truth for navigation. Add a page = add one entry here.
  const ROUTES = [
    { key: 'overview', label: 'Overview', path: 'index.html',
      icon: ICON('<rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect>') },
    { key: 'household', label: 'Household', path: 'pages/household.html',
      icon: ICON('<path d="M3 11l9-8 9 8"></path><path d="M5 10v10h14V10"></path>') },
    { key: 'collaboration-itad', label: 'Collaboration &amp; ITAD', path: 'pages/collaboration-itad.html',
      icon: ICON('<rect x="3" y="7" width="18" height="13" rx="2"></rect><path d="M9 7V4h6v3"></path>') },
    { key: 'material-database', label: 'Material Database', path: 'pages/material-database.html',
      icon: ICON('<ellipse cx="12" cy="6" rx="8" ry="3"></ellipse><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6"></path><path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"></path>') },
    { key: 'sop-library', label: 'SOP Library', path: 'pages/sop-library.html',
      icon: ICON('<path d="M4 4h12a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4z"></path><path d="M8 4v16"></path>') },
  ];
  const routeHref = (key) => {
    const r = ROUTES.find((x) => x.key === key);
    return r ? ROOT + '/' + r.path : '#';
  };

  /* ---------- sidebar ---------- */
  function buildSidebar() {
    const el = document.getElementById('sidebar');
    const items = ROUTES.map((r) => {
      const active = r.key === PAGE;
      return '<a class="nav-link' + (active ? ' is-active' : '') + '" href="' + routeHref(r.key) + '"' +
        (active ? ' aria-current="page"' : '') + '>' + r.icon + '<span>' + r.label + '</span></a>';
    }).join('');
    el.innerHTML =
      '<div class="brand">' +
        '<div class="brand-mark"><svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7"></path><path d="M21 4v5h-5"></path></svg></div>' +
        '<div><div class="brand-name">JALA</div><div class="brand-sub">Operations Management System</div></div>' +
        '<button type="button" class="sidebar-close" data-action="close-nav" aria-label="Tutup menu">' +
          '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' +
      '</div>' +
      '<nav aria-label="Menu utama" class="nav">' + items + '</nav>' +
      '<div class="sidebar-foot">' +
        (JALA.dataService.isDemoData ? '<span class="demo-pill" title="Semua angka di aplikasi ini adalah data contoh">Mode demo · data contoh</span>' : '') +
        '<div>Dashboard sebagai monitoring system sekaligus guideline untuk operational team.</div>' +
      '</div>';
  }

  /* ---------- mobile drawer ---------- */
  const backdrop = document.querySelector('.sidebar-backdrop');
  const menuBtn = document.querySelector('[data-action="open-nav"]');
  function setNav(open) {
    body.classList.toggle('nav-open', open);
    backdrop.hidden = !open;
    menuBtn.setAttribute('aria-expanded', String(open));
    if (open) document.querySelector('#sidebar .nav-link')?.focus();
  }

  /* ---------- dialog for features that need the database phase ---------- */
  const dialog = document.getElementById('app-dialog');
  function showInfo(title, text) {
    dialog.querySelector('#app-dialog-title').textContent = title;
    dialog.querySelector('.dialog-body').textContent = text;
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else window.alert(title + '\n\n' + text);
  }

  /* ---------- page rendering ---------- */
  const main = document.getElementById('main');
  const pageBody = main.querySelector('.page-body');
  const pristine = pageBody.cloneNode(true); // untouched templates, for re-render
  let currentBody = pageBody;

  function setState(state, message) {
    main.dataset.state = state;
    main.setAttribute('aria-busy', String(state === 'loading'));
    if (message) main.querySelector('.state-error-msg').textContent = message;
  }

  function wireLinks(scope) {
    scope.querySelectorAll('a[data-route]').forEach((a) => { a.href = routeHref(a.dataset.route); });
    scope.querySelectorAll('button[type="button"]:not([data-action])').forEach((b) => {
      b.addEventListener('click', () => showInfo(
        b.textContent.trim().replace(/^\+\s*/, ''),
        'Fitur ini belum aktif. Untuk menyimpan data bersama antar karyawan, fitur input akan diaktifkan pada tahap berikutnya setelah database dan login karyawan terpasang. Saat ini aplikasi menampilkan data contoh.'
      ));
    });
  }

  async function renderPage(params) {
    setState('loading');
    try {
      const data = await JALA.dataService.getPageData(PAGE, params);
      const fresh = pristine.cloneNode(true);
      JALA.template.render(fresh, data);
      wireLinks(fresh);
      currentBody.replaceWith(fresh);
      currentBody = fresh;
      pageHooks(fresh, params);
      setState('ready');
    } catch (err) {
      console.error('[JALA] render failed:', err);
      setState('error', err && err.message ? err.message : String(err));
    }
  }

  // Page-specific behaviour
  function pageHooks(scope, params) {
    const period = scope.querySelector('#bulan');
    if (period) {
      if (params && params.period) period.value = params.period;
      period.addEventListener('change', () => renderPage({ period: period.value }));
    }
  }

  /* ---------- global events ---------- */
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-action]');
    if (!t) return;
    const a = t.dataset.action;
    if (a === 'open-nav') setNav(true);
    else if (a === 'close-nav') setNav(false);
    else if (a === 'retry') renderPage();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && body.classList.contains('nav-open')) { setNav(false); menuBtn.focus(); }
  });
  window.matchMedia('(min-width: 1024px)').addEventListener('change', (m) => { if (m.matches) setNav(false); });

  buildSidebar();
  renderPage();
})();
