/*
 * JALA – runtime configuration.
 *
 * dataSource:
 *   'dummy'    – (current) reads example data from assets/js/data/dummy-data.js
 *   'supabase' – (future) reads from Supabase. Not implemented yet.
 *
 * Supabase note for the future: the project URL and the *anon/publishable* key
 * are designed to be public and may live here. Security then comes from
 * Row Level Security (RLS) policies in Supabase. NEVER put the service_role
 * key, passwords or any other secret in this file or anywhere in the repo.
 */
window.JALA = window.JALA || {};
window.JALA.config = {
  appName: 'JALA – Operations Management System',
  appShortName: 'JALA',
  dataSource: 'dummy',
  supabase: {
    url: '',      // e.g. https://xxxx.supabase.co  (phase 2)
    anonKey: '',  // public anon key only (phase 2)
  },
};
