/*
 * DUMMY DATA – for display and testing only.
 * Every figure here is example data copied from the original dashboard design.
 * Do NOT put confidential company or client data in this file: it is public
 * to anyone who opens the website (and to anyone who can see the repository).
 * In the database phase this file is replaced by Supabase tables.
 */
window.JALA = window.JALA || {};
window.JALA.dummyData = {
  "overview": {
    "cats": [
      {
        "name": "Household",
        "count": 7,
        "href": "household",
        "desc": "Pengelolaan e-waste household sampai assessment, grouping, dismantling, dan sales.",
        "stages": [
          {
            "label": "Request"
          },
          {
            "label": "Pickup"
          },
          {
            "label": "Weighing"
          },
          {
            "label": "Sorting"
          },
          {
            "label": "Assessment"
          },
          {
            "label": "Dismantling"
          },
          {
            "label": "Material Output"
          }
        ]
      },
      {
        "name": "Collaboration Other",
        "count": 6,
        "href": "collaboration-itad",
        "desc": "Pengelolaan project collaboration berdasarkan SOP masing-masing project.",
        "stages": [
          {
            "label": "BAST"
          },
          {
            "label": "Weighing"
          },
          {
            "label": "Sorting"
          },
          {
            "label": "Dismantling"
          },
          {
            "label": "Mass Dismantling"
          },
          {
            "label": "Report"
          }
        ]
      },
      {
        "name": "ITAD – Company",
        "count": 7,
        "href": "collaboration-itad",
        "desc": "Tracking asset, weighing, dismantling, material output, dan potential revenue.",
        "stages": [
          {
            "label": "BAST"
          },
          {
            "label": "Weighing"
          },
          {
            "label": "Asset Check"
          },
          {
            "label": "Whole Unit Dismantling"
          },
          {
            "label": "Mass Dismantling"
          },
          {
            "label": "Material Output"
          },
          {
            "label": "Report"
          }
        ]
      }
    ],
    "phases": [
      {
        "title": "Intake",
        "steps": [
          {
            "n": 1,
            "label": "Request",
            "note": "Request diterima"
          },
          {
            "n": 2,
            "label": "Create Project",
            "note": "Pilih jenis project"
          },
          {
            "n": 3,
            "label": "Pickup & BAST",
            "note": "Dokumentasi pickup"
          },
          {
            "n": 4,
            "label": "Verification",
            "note": "Jenis, quantity, brand"
          }
        ]
      },
      {
        "title": "Processing",
        "steps": [
          {
            "n": 5,
            "label": "Weighing",
            "note": "Penimbangan + dokumentasi"
          },
          {
            "n": 6,
            "label": "Sorting",
            "note": "Pisah per jenis e-waste"
          },
          {
            "n": 7,
            "label": "Assessment / Processing",
            "note": "Repair · Dismantling · Shredding"
          }
        ]
      },
      {
        "title": "Output",
        "steps": [
          {
            "n": 8,
            "label": "Final Weighing",
            "note": "Raw material & hasil shredding"
          },
          {
            "n": 9,
            "label": "Documentation Check",
            "note": "Syarat Disposal Report"
          },
          {
            "n": 10,
            "label": "Material Report",
            "note": "Input → Process → Output"
          }
        ]
      },
      {
        "title": "Business",
        "steps": [
          {
            "n": 11,
            "label": "Material Inventory",
            "note": "Otomatis dari semua project"
          },
          {
            "n": 12,
            "label": "Sales",
            "note": "Material siap ditawarkan"
          },
          {
            "n": 13,
            "label": "Potential Revenue",
            "note": "Estimasi nilai material"
          },
          {
            "n": 14,
            "label": "Project Evaluation",
            "note": "Nilai ekonomi project"
          }
        ]
      }
    ],
    "bca": [
      {
        "label": "Battery",
        "kg": "1,500",
        "pct": "37.5%",
        "bar": "100%"
      },
      {
        "label": "Iron",
        "kg": "1,200",
        "pct": "30%",
        "bar": "80%"
      },
      {
        "label": "Plastic",
        "kg": "400",
        "pct": "10%",
        "bar": "26.7%"
      },
      {
        "label": "Cable",
        "kg": "350",
        "pct": "8.8%",
        "bar": "23.3%"
      },
      {
        "label": "Other",
        "kg": "300",
        "pct": "7.5%",
        "bar": "20%"
      },
      {
        "label": "PCB",
        "kg": "250",
        "pct": "6.3%",
        "bar": "16.7%"
      }
    ],
    "tiles": [
      {
        "title": "Visibility",
        "text": "Semua project terpantau end-to-end"
      },
      {
        "title": "Traceability",
        "text": "Data & dokumentasi bisa ditelusuri"
      },
      {
        "title": "Operational Efficiency",
        "text": "SOP terintegrasi di dashboard"
      },
      {
        "title": "Business Value",
        "text": "Output & potential revenue terlihat"
      }
    ]
  },
  "household": {
    "flow": [
      {
        "title": "A. Request & Pickup",
        "steps": [
          {
            "n": 1,
            "label": "Request diterima"
          },
          {
            "n": 2,
            "label": "Pickup dilaksanakan"
          },
          {
            "n": 3,
            "label": "E-waste diterima di facility"
          }
        ]
      },
      {
        "title": "B. Verification & Weighing",
        "steps": [
          {
            "n": 4,
            "label": "Verifikasi e-waste"
          },
          {
            "n": 5,
            "label": "Penimbangan"
          },
          {
            "n": 6,
            "label": "Dokumentasi hasil penimbangan"
          }
        ]
      },
      {
        "title": "C. Sorting",
        "steps": [
          {
            "n": 7,
            "label": "Pisah per jenis: Cable, Printer, Handphone, Iron, Laptop, TV, lainnya"
          }
        ]
      },
      {
        "title": "D. Functional Assessment",
        "steps": [
          {
            "n": 8,
            "label": "Functional / Potentially Repairable"
          },
          {
            "n": 9,
            "label": "Non-Functional: Dismantle atau Sell as Whole Unit"
          }
        ]
      }
    ],
    "monthly": [
      {
        "type": "Cable",
        "qty": "125",
        "unit": "kg"
      },
      {
        "type": "Printer",
        "qty": "35",
        "unit": "unit"
      },
      {
        "type": "Handphone",
        "qty": "48",
        "unit": "unit"
      },
      {
        "type": "Iron",
        "qty": "27",
        "unit": "unit"
      },
      {
        "type": "Laptop",
        "qty": "15",
        "unit": "unit"
      }
    ],
    "dism": [
      {
        "title": "Before Dismantling",
        "text": "Grouping per jenis, hitung jumlah unit, dokumentasi sebelum dismantling, catat unit yang akan diproses."
      },
      {
        "title": "Dismantling",
        "text": "Proses dismantling, dokumentasi proses, pemisahan raw material."
      },
      {
        "title": "Material Output",
        "text": "Timbang tiap raw material, dokumentasi, input ke dashboard, reporting total material."
      }
    ],
    "outputs": [
      {
        "label": "Iron / Metal: XX kg"
      },
      {
        "label": "Plastic: XX kg"
      },
      {
        "label": "PCB: XX kg"
      },
      {
        "label": "Cable: XX kg"
      },
      {
        "label": "Other: XX kg"
      }
    ]
  },
  "collaboration-itad": {
    "stages": [
      {
        "n": 1,
        "label": "BAST",
        "note": "Disiapkan & ditandatangani kedua pihak"
      },
      {
        "n": 2,
        "label": "Initial Weighing",
        "note": "Timbang & verifikasi vs BAST"
      },
      {
        "n": 3,
        "label": "Whole Unit Dismantling",
        "note": "Sample 1 unit untuk komposisi"
      },
      {
        "n": 4,
        "label": "Mass Dismantling",
        "note": "Bongkar masal per jenis"
      },
      {
        "n": 5,
        "label": "Shredding",
        "note": "Material yang perlu dicacah"
      },
      {
        "n": 6,
        "label": "Final Weighing",
        "note": "Timbang material output"
      },
      {
        "n": 7,
        "label": "Material Report",
        "note": "Project Material Output Report"
      }
    ],
    "bast": [
      {
        "type": "UPS A",
        "bast": "100",
        "actual": "100",
        "weight": "XXX kg"
      },
      {
        "type": "UPS B",
        "bast": "100",
        "actual": "100",
        "weight": "XXX kg"
      }
    ],
    "wuFlow": [
      {
        "label": "Dismantle"
      },
      {
        "label": "Separate"
      },
      {
        "label": "Weigh"
      },
      {
        "label": "Document"
      },
      {
        "label": "Report"
      }
    ],
    "comps": [
      {
        "name": "Battery"
      },
      {
        "name": "Iron"
      },
      {
        "name": "Cable"
      },
      {
        "name": "PCB"
      }
    ],
    "mass": [
      {
        "n": 1,
        "label": "200 UPS",
        "note": "masuk antrean dismantling"
      },
      {
        "n": 2,
        "label": "Dismantling",
        "note": "masal per jenis e-waste"
      },
      {
        "n": 3,
        "label": "Sorting",
        "note": "Battery · Iron · Cable · PCB · Plastic"
      },
      {
        "n": 4,
        "label": "Weighing",
        "note": "per jenis material"
      },
      {
        "n": 5,
        "label": "Documentation",
        "note": "lengkap untuk Disposal Report"
      },
      {
        "n": 6,
        "label": "Dashboard",
        "note": "input hasil timbang"
      }
    ],
    "shred": [
      {
        "n": 1,
        "label": "Input Material",
        "note": "material yang perlu shredding"
      },
      {
        "n": 2,
        "label": "Shredding",
        "note": ""
      },
      {
        "n": 3,
        "label": "Output Material",
        "note": "per jenis material"
      },
      {
        "n": 4,
        "label": "Penimbangan",
        "note": "setelah shredding"
      },
      {
        "n": 5,
        "label": "Dokumentasi",
        "note": "bagian dari supporting evidence"
      },
      {
        "n": 6,
        "label": "Input Dashboard",
        "note": ""
      }
    ],
    "out": [
      {
        "label": "Battery",
        "kg": "1,500",
        "bar": "100%"
      },
      {
        "label": "Iron",
        "kg": "1,200",
        "bar": "80%"
      },
      {
        "label": "Plastic",
        "kg": "400",
        "bar": "26.7%"
      },
      {
        "label": "Cable",
        "kg": "350",
        "bar": "23.3%"
      },
      {
        "label": "Other",
        "kg": "300",
        "bar": "20%"
      },
      {
        "label": "PCB",
        "kg": "250",
        "bar": "16.7%"
      }
    ],
    "docs": [
      {
        "label": "BAST ditandatangani kedua pihak"
      },
      {
        "label": "Foto penimbangan awal"
      },
      {
        "label": "Dokumentasi whole unit dismantling"
      },
      {
        "label": "Dokumentasi mass dismantling"
      },
      {
        "label": "Dokumentasi penimbangan material"
      },
      {
        "label": "Dokumentasi shredding"
      }
    ]
  },
  "material-database": {
    "kpis": [
      {
        "label": "Total raw material",
        "value": "3,270 kg"
      },
      {
        "label": "Jenis raw material",
        "value": "4"
      },
      {
        "label": "Item functional (contoh)",
        "value": "4 unit"
      }
    ],
    "rows": [
      {
        "material": "Iron",
        "weight": "1,500",
        "source": "BCA UPS",
        "date": "DD/MM/2026"
      },
      {
        "material": "Cable",
        "weight": "650",
        "source": "Household",
        "date": "DD/MM/2026"
      },
      {
        "material": "PCB",
        "weight": "320",
        "source": "ITAD",
        "date": "DD/MM/2026"
      },
      {
        "material": "Plastic",
        "weight": "800",
        "source": "Collaboration",
        "date": "DD/MM/2026"
      }
    ],
    "items": [
      {
        "name": "Laptop",
        "date": "DD/MM/2026"
      },
      {
        "name": "Handphone",
        "date": "DD/MM/2026"
      },
      {
        "name": "Printer",
        "date": "DD/MM/2026"
      },
      {
        "name": "TV",
        "date": "DD/MM/2026"
      }
    ],
    "bars": [
      {
        "material": "Iron",
        "weight": "1,500",
        "bar": "100%"
      },
      {
        "material": "Plastic",
        "weight": "800",
        "bar": "53.3%"
      },
      {
        "material": "Cable",
        "weight": "650",
        "bar": "43.3%"
      },
      {
        "material": "PCB",
        "weight": "320",
        "bar": "21.3%"
      }
    ],
    "chain": [
      {
        "label": "Material Database"
      },
      {
        "label": "Sales Database"
      },
      {
        "label": "Potential Revenue"
      }
    ]
  },
  "sop-library": {
    "groups": [
      {
        "title": "Household SOP",
        "items": [
          {
            "label": "Pickup SOP"
          },
          {
            "label": "Weighing SOP"
          },
          {
            "label": "Assessment SOP"
          },
          {
            "label": "Dismantling SOP"
          },
          {
            "label": "Documentation SOP"
          }
        ]
      },
      {
        "title": "Company / ITAD SOP",
        "items": [
          {
            "label": "BAST SOP"
          },
          {
            "label": "Weighing SOP"
          },
          {
            "label": "Whole Unit Dismantling SOP"
          },
          {
            "label": "Mass Dismantling SOP"
          },
          {
            "label": "Mass Shredding SOP"
          },
          {
            "label": "Other Process SOP (jika dibutuhkan)"
          },
          {
            "label": "Material Reporting SOP"
          }
        ]
      }
    ],
    "bca": [
      {
        "step": "Langkah 1",
        "label": "BAST"
      },
      {
        "step": "Langkah 2",
        "label": "Initial Weighing"
      },
      {
        "step": "Langkah 3",
        "label": "Whole Unit Dismantling"
      },
      {
        "step": "Langkah 4",
        "label": "Mass Dismantling"
      },
      {
        "step": "Langkah 5",
        "label": "Shredding"
      },
      {
        "step": "Langkah 6",
        "label": "Material Reporting"
      }
    ]
  }
};
