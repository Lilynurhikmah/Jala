-- =====================================================================
-- JALA – DRAFT database schema for Supabase (Phase 2)
-- STATUS: DRAFT. Not applied anywhere. Review before use.
-- Mirrors the data shown in the Phase 1 dashboard.
-- =====================================================================

-- Roles -----------------------------------------------------------------
create type app_role as enum ('admin', 'operations', 'sales', 'viewer');

create table profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null,
  role        app_role not null default 'viewer',
  created_at  timestamptz not null default now()
);

-- Projects ----------------------------------------------------------------
create type project_type as enum ('household', 'collaboration', 'itad');

create table projects (
  id            uuid primary key default gen_random_uuid(),
  code          text unique,                 -- e.g. 'ITAD-2026-001'
  name          text not null,               -- e.g. 'UPS Project'
  client_name   text,
  type          project_type not null,
  current_stage text,                        -- e.g. 'Weighing'
  input_units   integer,
  input_kg      numeric(12,2),
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now()
);

create table project_stages (               -- progress through the SOP flow
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid not null references projects(id) on delete cascade,
  stage        text not null,
  status       text not null default 'pending' check (status in ('pending','in_progress','done')),
  completed_at timestamptz,
  completed_by uuid references profiles(id)
);

-- Material output & sales inventory ----------------------------------------
create table material_outputs (             -- Raw Material table (per kg)
  id            uuid primary key default gen_random_uuid(),
  project_id    uuid not null references projects(id),
  material      text not null,              -- Battery, Iron, Plastic, Cable, PCB, Other
  weight_kg     numeric(12,2) not null check (weight_kg >= 0),
  entry_date    date not null default current_date,
  for_sale      boolean not null default true,
  price_per_kg  numeric(14,2),
  photo_path    text                         -- Supabase Storage path
);

create table functional_items (             -- Item Functional table (per unit)
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid references projects(id),
  item         text not null,               -- Laptop, Handphone, ...
  brand_type   text,
  entry_date   date not null default current_date,
  second_price numeric(14,2),
  photo_path   text
);

-- SOP library ----------------------------------------------------------------
create table sops (
  id          uuid primary key default gen_random_uuid(),
  group_name  text not null,                -- 'Household SOP', 'Company / ITAD SOP', 'BCA – UPS'
  title       text not null,
  file_path   text,                         -- PDF in Supabase Storage
  version     text,
  updated_at  timestamptz not null default now()
);

-- Activity log -------------------------------------------------------------
create table activity_log (
  id          bigint generated always as identity primary key,
  actor       uuid references profiles(id),
  action      text not null,                -- 'insert' | 'update' | 'delete'
  table_name  text not null,
  record_id   text,
  details     jsonb,
  created_at  timestamptz not null default now()
);

-- Row Level Security (example policies – extend per table) ------------------
alter table profiles          enable row level security;
alter table projects          enable row level security;
alter table project_stages    enable row level security;
alter table material_outputs  enable row level security;
alter table functional_items  enable row level security;
alter table sops              enable row level security;
alter table activity_log      enable row level security;

create or replace function current_role_is(r app_role[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = any(r));
$$;

-- every signed-in employee can read
create policy "read: employees" on projects for select to authenticated using (true);
create policy "read: employees" on material_outputs for select to authenticated using (true);
create policy "read: employees" on sops for select to authenticated using (true);

-- only admin / operations can write project data
create policy "write: ops" on projects for insert to authenticated
  with check (current_role_is(array['admin','operations']::app_role[]));
create policy "update: ops" on projects for update to authenticated
  using (current_role_is(array['admin','operations']::app_role[]));

-- sales can update prices on material outputs
create policy "update: sales+ops" on material_outputs for update to authenticated
  using (current_role_is(array['admin','operations','sales']::app_role[]));

-- users see their own profile; admins see all
create policy "profile: self or admin" on profiles for select to authenticated
  using (id = auth.uid() or current_role_is(array['admin']::app_role[]));

-- activity log: admins only
create policy "log: admin read" on activity_log for select to authenticated
  using (current_role_is(array['admin']::app_role[]));
