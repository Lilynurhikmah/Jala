# JALA – Roadmap

## Phase 1: Website online (this version) ✅
Static site on Netlify Free. Shows example data and has no login or saving.

## Phase 2: Database and employee login (Supabase Free)
Goal: employees sign in and share the same, real data.

1. **Create a Supabase project** (free tier) and run a reviewed version of
   `docs/supabase-schema.draft.sql`.
2. **Auth:** Supabase Auth with email + password or magic link. Only invited
   company emails can sign in (turn off public sign-ups).
3. **Roles (RBAC):** `admin`, `operations`, `sales`, `viewer`, stored in the `profiles` table.
   Enforced by **Row Level Security policies in the database**, not just by hiding
   buttons in the browser.
4. **Frontend changes:**
   * `config.js`: set `dataSource: 'supabase'`, plus the project URL and the *anon* key
     (public by design; safe only with RLS on).
   * `data-service.js`: implement `supabaseAdapter.getPageData()` so it returns the
     same shape as `dummy-data.js`. The pages and templates do not change.
   * Add `login.html`, and redirect to it when there is no session.
   * Wire "+ Create Project" and "+ Input E-Waste Baru" to real forms.
5. **File uploads:** Supabase Storage buckets for weighing photos, BAST scans and SOP PDFs,
   with storage policies for each role.
6. **Activity log:** an `activity_log` table filled by database triggers (who changed what, and when).

## Phase 3: Operations features
* Material inventory calculated automatically from project outputs
* Potential revenue (price per kg × available weight)
* Reports and exports (CSV / PDF) per project and per period
* Real month filter in Material Database

## Free-tier notes (check current limits before relying on them)
* **Supabase Free:** limited database size, storage and monthly users. Projects
  **pause after a period of inactivity** and must be resumed from the dashboard.
  There are no automatic backups on Free, so export data regularly.
* **Netlify Free:** monthly bandwidth and build allowance. Plenty for this site.

## Security rules
* Never commit the Supabase `service_role` key, passwords or `.env` files.
* Keep confidential client data in the database (behind login), never in the repository.
